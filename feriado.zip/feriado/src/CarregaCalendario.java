public class CarregaCalendario {
    protected static Calendarios cargaCalendarios() {
        Calendarios calendarios = new Calendarios();

        Calendario calendario1 = new Calendario();
        calendario1.setTipo("Nacional");
        calendario1.setNacional(false);
        calendario1.setSabado(true);
        calendario1.setDomingo(true);
        calendario1.incluirFeriado("01/01/2023");
        calendario1.incluirFeriado("20/02/2023");
        calendario1.incluirFeriado("21/02/2023");
        calendario1.incluirFeriado("07/04/2023");
        calendario1.incluirFeriado("21/04/2023");
        calendario1.incluirFeriado("01/05/2023");
        calendario1.incluirFeriado("08/06/2023");
        calendario1.incluirFeriado("07/09/2023");
        calendario1.incluirFeriado("12/10/2023");
        calendario1.incluirFeriado("02/11/2023");
        calendario1.incluirFeriado("15/11/2023");
        calendario1.incluirFeriado("25/12/2023");
        calendarios.incluirCalendario(new Calendario(calendario1));

        Calendario calendario2 = new Calendario();
        calendario2.setTipo("SP");
        calendario1.setNacional(true);
        calendario2.setSabado(true);
        calendario2.setDomingo(true);
        calendario2.incluirFeriado("25/01/2023");
        calendario2.incluirFeriado("20/11/2023");
        calendarios.incluirCalendario(new Calendario(calendario2));

        System.out.println("-------------------------------------------");
        System.out.println("-  CALENDÁRIOS CARREGADOS!                -");
        System.out.println("-------------------------------------------");
        return calendarios;
    }

}

