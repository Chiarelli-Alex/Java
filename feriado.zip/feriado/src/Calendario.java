import java.util.ArrayList;
import java.util.HashMap;


public class Calendario {

    private String tipo;

    private int i;

    private boolean nacional = true;

    private boolean sabado = true;
    private boolean domingo = true;

    private ArrayList<String> listFeriados = new ArrayList<String>();
    private HashMap<String, String> mapFeriados = new HashMap<String, String>();

    public Calendario() {

    }

    public Calendario(String tipo, boolean nacional, boolean sabado, boolean domingo) {

        this.tipo = tipo;
        this.nacional = nacional;
        this.sabado = sabado;
        this.domingo = domingo;

    }

    public Calendario(Calendario calendario) {
        setTipo(calendario.tipo);
        setNacional(calendario.nacional);
        setSabado(calendario.sabado);
        setDomingo(calendario.domingo);
        setListFeriados(calendario.listFeriados);
        setMapFeriados(calendario.mapFeriados);
    }

    public String getTipo() {
        return tipo;
    }

    public boolean isNacional() {
        return nacional;
    }

    public boolean isSabado() {
        return sabado;
    }

    public boolean isDomingo() {
        return domingo;
    }


    public HashMap<String, String> getMapFeriados() {
        return mapFeriados;
    }
    public ArrayList<String> getListFeriados() {
        return listFeriados;
    }
    public String getListFeriados(int i) {
        return listFeriados.get(i);
    }



    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setI(int i) {
        this.i = i;
    }

    public void setNacional(boolean nacional) {
        this.nacional = nacional;
    }

    public void setSabado(boolean sabado) {
        this.sabado = sabado;
    }

    public void setDomingo(boolean domingo) {
        this.domingo = domingo;
    }

    public void setListFeriados(ArrayList<String> listFeriados) {
        this.listFeriados = listFeriados;
    }

    public void setMapFeriados(HashMap<String, String> mapFeriados) {
        this.mapFeriados = mapFeriados;
    }

    public void incluirFeriado(String novoFeriado) {
        listFeriados.add(novoFeriado);
        mapFeriados.put(novoFeriado, novoFeriado);
        return;
    }


    @Override
    public String toString() {
        return "Calendario{" +
                "tipo='" + tipo + '\'' +
                ", i=" + i +
                ", nacional=" + nacional +
                ", sabado=" + sabado +
                ", domingo=" + domingo +
                ", listFeriados=" + listFeriados +
                ", mapFeriados=" + mapFeriados +
                '}';
    }

}

