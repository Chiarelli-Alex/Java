import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

public class TrataUtil {
    public static void main(String[] args) throws ParseException {

        //Captura calendario
        String calendarioRef = "";
        //calendarioRef = capturaCalendario();

        //Capturar data do usuário
        Date dataRef = new Date();
        dataRef = capturaData();

        //Captura dias a ser somado ou diminuído
        int diasRef = capturaDias();



        System.out.println("Fim!");
    }

    private static String capturaCalendario() {

        String calendarioUser = "";

        //Capturar informações do usuário
        Scanner leitura = new Scanner(System.in);

        boolean valida = false;


        while (valida == false) {

                System.out.println("Informe o calendário a ser utilizado: ");
                calendarioUser  = leitura.nextLine();

                if (calendarioUser == "") {
                    System.out.println("Calendário inválido!");
                    valida = false;
                }
                else {
                    valida = true;
                    }



        }

        return calendarioUser;
    }


    private static Date capturaData() throws ParseException {


        Date dataAtual = new Date();
        Date dataRef = new Date();
        Date dataUser = new Date();

        Calendar cal = Calendar.getInstance();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        //Capturar informações do usuário
        Scanner leitura = new Scanner(System.in);

        //System.out.println(dataFormatada(dataAtual));



        System.out.println("Informe a date de referência no formato (dd/mm/aaaa): ");
        String dataStrUser = leitura.nextLine();

        boolean valida = false;

        while (valida == false) {

            if (dataStrUser.equals("")) {
                dataUser = dataAtual;
                valida = true;
            } else {

                try {
                    LocalDate dateUser = LocalDate.parse(dataStrUser, dateTimeFormat);
                    valida = true;
                } catch (Exception a) {
                    System.out.println("Data inválida!");
                    System.out.println("Informe a date de referência no formato (dd/mm/aaaa): ");
                    dataStrUser = leitura.nextLine();
                }

            }
        }

        if (dataStrUser.equals("")) {
            dataRef = dataAtual;
            System.out.println("Data não informada. Será considerada a data atual! (" + dataFormatada(dataRef) + ")");
        }
        else {
            dataUser = dateFormat.parse(dataStrUser);
            dataRef = dataUser;
        }

        return dataRef;

    }

    private static int capturaDias() {

        int diasUser = 0;


        Scanner leitura = new Scanner(System.in);

        boolean valida = false;

        while (valida == false) {
            System.out.println("Informe a quantidade de dias úteis que pretende somar/diminuir: ");

            try {
                diasUser = leitura.nextInt();
                valida = true;
            } catch (InputMismatchException a) {
                System.out.println("Quantidade de dias ínválido!");
                valida = false;
                leitura.next();
            }
        }

        return diasUser;
    }

    private static String dataFormatada(Date dataAtual) {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String dataFormatada;


        dataFormatada = dateFormat.format(dataAtual);
        return dataFormatada;
    }


    public static void trataData(Calendarios calendarios) throws ParseException {

        Calendario calendario = new Calendario();
        Calendario calendarioN = new Calendario();
        String userCalendario = "";
        Date userData = new Date();
        int userDias = 0;
        int dias = 0;
        int mult = 1;
        boolean diaUtil = false;
        Date novaData = new Date();

        //Captura calendario
        //userCalendario = capturaCalendario();
        //System.out.println("Calendário Informado: " + userCalendario);

        //Pesquisa calendario específico
        boolean valida = false;

        while (valida == false) {
            userCalendario = capturaCalendario();
            calendario = ListaCalendario.listaCalendario(calendarios, userCalendario);

            if (calendario == null) {
                valida = false;
            }
            else {
                valida = true;
            }
        }

        //Pesquisa calendario Nacional
        if (userCalendario.equals("Nacional")) {
            calendarioN = calendario;
        }
        else {
            calendarioN = ListaCalendario.listaCalendario(calendarios, "Nacional");
            //System.out.println("Calendário Nacional: " + calendarioN);
        }


        if (calendario == null) {
            //System.out.println("Calendario não encontrado.");
        }
        else{
            //System.out.println("Calendário encontrado: " + calendario);

            // Captura Data
            userData = TrataUtil.capturaData();
            //System.out.println("Data informada: " + dataFormatada(userData));

            // Captura Dias
            userDias = TrataUtil.capturaDias();
            dias = userDias;
            //System.out.println("Dia(s) informado(s): " + userDias);

            if (dias == 0) {
                diaUtil = TrataUtil.isUtil(userData, calendario, calendarioN);
                //System.out.println("Dia útil: " + diaUtil);
                if (diaUtil == false) {
                    dias = 1;
                }
            }


           if (dias < 0) {
               mult = -1;
               dias = dias * mult;
           }
           else {
               mult = 1;
           }


           novaData = userData;

            Calendar cal = Calendar.getInstance();
            cal.setTime(novaData);


            while (dias != 0) {
                //System.out.println("Repetição " + (dias * mult));

                cal.add(Calendar.DATE, (1 * mult));
                novaData = cal.getTime();

                diaUtil = TrataUtil.isUtil(novaData, calendario, calendarioN);
                //System.out.println("Dt: " + dataFormatada(novaData) + " útil? " + diaUtil);

                if (diaUtil) {
                    dias = dias -1;
                }

            }

        }

        if (userDias ==0 && userData != novaData) {
            System.out.println("Data " + dataFormatada(userData) + " não útil! Próxima data útil será: " + dataFormatada(novaData));
        }
        else {
            System.out.println("Data resultante: " + dataFormatada(novaData));
        }


    }

    private static boolean isUtil(Date userData, Calendario calendario, Calendario calendarioN) {

        Calendar cal = Calendar.getInstance();
        cal.setTime(userData);
        int diaDaSemana = cal.get(Calendar.DAY_OF_WEEK);

        if (calendario.isSabado() && diaDaSemana == Calendar.SATURDAY) {
            System.out.println(dataFormatada(userData) + " - Sábado não útil conforme calendário específico!");
            return false;
        }

        if (calendario.isDomingo() && diaDaSemana == Calendar.SUNDAY) {
            System.out.println(dataFormatada(userData) + " - Domingo não útil conforme calendário específico!");
            return false;
        }

        //Calendário Nacional
        if (calendario.isNacional() && calendarioN.getMapFeriados().containsKey(dataFormatada(userData))) {
            System.out.println(dataFormatada(userData) + " - Feriado conforme calendário nacional!");
            return false;
        }


        // Calendário Específico
        if (calendario.getMapFeriados().containsKey(dataFormatada(userData))) {
            System.out.println(dataFormatada(userData) + " - Feriado conforme calendário específico!");
            return false;
        }


        return true;
    }


}