import java.util.ArrayList;
import java.util.HashMap;


public class Calendarios extends Calendario{
    private HashMap<String, Calendario> mapCalendarios = new HashMap<String, Calendario>();
    private ArrayList<Calendario> listCalendarios = new ArrayList<Calendario>();
    public void incluirCalendario(Calendario novoCalendario) {
         int i = mapCalendarios.size();
        novoCalendario.setI(i + 1);
        listCalendarios.add(novoCalendario);
        mapCalendarios.put(novoCalendario.getTipo(), novoCalendario);
        return;
    }

    public Calendario getListCalendarios(int i) {
        return listCalendarios.get(i);
    }
    public HashMap<String, Calendario> getMapCalendarios() {
        return mapCalendarios;
    }



}
