public class ListaCalendario {


    protected static Calendario listaCalendario(Calendarios listaCalendarios, String tipo) {
        Calendario calendario = new Calendario();

        System.out.println("-------------------------------------------");
        System.out.println("-  CALENDÁRIO (ESPECÍFICO)                -");
        System.out.println("-------------------------------------------");

        if (listaCalendarios.getMapCalendarios().containsKey(tipo)) {
            calendario = listaCalendarios.getMapCalendarios().get(tipo);
            System.out.println("Calendário: " + calendario.getTipo());
            System.out.println("Adicionar feriados Nacionais: " + calendario.isNacional());
            System.out.println("Sábado considerado não útil?: " + calendario.isSabado());
            System.out.println("Domingo considerado não útil?: " + calendario.isDomingo());
            System.out.println("-------------------------------------------");

            for (int x = 0; x < calendario.getMapFeriados().size(); x++) {
                String feriado = calendario.getListFeriados(x);
                System.out.println("Data: " + feriado);
            }

            if (calendario.getMapFeriados().size() == 0) {
                System.out.println("Sem datas cadastradas!!                    ");
                System.out.println("-------------------------------------------");

            }

            return calendario;

        }
        else {
            System.out.println("-------------------------------------------");
            System.out.println("Calendário [" + tipo + "] não cadastrado!");
            System.out.println("-------------------------------------------");
            return null;
        }

    }


    protected static void listaTodosCalendarios(Calendarios listaCalendarios) {
        Calendario calendario = new Calendario();

        System.out.println("-------------------------------------------");
        System.out.println("-  CALENDÁRIOS  (TODOS)                   -");
        System.out.println("-------------------------------------------");

        for(int i = 0; i < listaCalendarios.getMapCalendarios().size(); i++) {
            calendario = listaCalendarios.getListCalendarios(i);
            System.out.println("Calendário: " + calendario.getTipo());
            System.out.println("Adicionar feriados Nacionais: " + calendario.isNacional());
            System.out.println("Sábado considerado não útil?: " + calendario.isSabado());
            System.out.println("Domingo considerado não útil?: " + calendario.isDomingo());



            for(int x = 0; x < calendario.getMapFeriados().size(); x++) {
                String feriado = calendario.getListFeriados(x);
                System.out.println("Data: " + feriado);
            }

            if (calendario.getMapFeriados().size() == 0) {
                System.out.println("-------------------------------------------");
                System.out.println("Sem datas cadastradas!!                    ");

            }
            else {
                System.out.println("-------------------------------------------");
            }

        }

        if (listaCalendarios.getMapCalendarios().size() == 0) {
            System.out.println("-------------------------------------------");
            System.out.println("Sem calendários cadastrados!!              ");

        }

        System.out.println("-------------------------------------------");

    }
}

