import java.text.ParseException;

public class Main {
    public static void main(String[] args) throws ParseException {
        Calendarios calendarios = new Calendarios();

        // Carrega calendarios
        calendarios = CarregaCalendario.cargaCalendarios();

        //Lista todos calendarios
        ListaCalendario.listaTodosCalendarios(calendarios);

        // Pesquisar um calendario específico
        //ListaCalendario.listaCalendario(calendarios, "SP");

        //Trata Data
        TrataUtil.trataData(calendarios);


    }

}
